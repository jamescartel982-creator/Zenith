"""Illustrative LoRA fine-tuning pipeline for a small causal language model."""
import argparse
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-model", default="distilgpt2")
    parser.add_argument("--output-dir", default="artifacts/self-improving-agent-lora")
    parser.add_argument("--epochs", type=float, default=1.0)
    args = parser.parse_args()

    from datasets import Dataset
    from transformers import AutoModelForCausalLM, AutoTokenizer, Trainer, TrainingArguments
    from peft import LoraConfig, TaskType, get_peft_model

    data_path = Path("data/training.jsonl")
    if not data_path.exists():
        raise SystemExit("Missing data/training.jsonl. Export and manually review approved examples first.")
    rows = []
    for line in data_path.read_text(encoding="utf-8").splitlines():
        try:
            row = json.loads(line)
            if isinstance(row.get("text"), str) and row["text"].strip():
                rows.append({"text": row["text"]})
        except json.JSONDecodeError:
            continue
    if len(rows) < 5:
        raise SystemExit("Please collect at least 5 reviewed examples; more diverse examples are strongly recommended.")

    tokenizer = AutoTokenizer.from_pretrained(args.base_model)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(args.base_model)
    config = LoraConfig(
        task_type=TaskType.CAUSAL_LM,
        r=8,
        lora_alpha=16,
        lora_dropout=0.05,
        target_modules=["c_attn"] if "gpt2" in args.base_model.lower() else None,
    )
    model = get_peft_model(model, config)

    dataset = Dataset.from_list(rows)
    def tokenize(batch):
        tokens = tokenizer(batch["text"], truncation=True, max_length=256, padding="max_length")
        tokens["labels"] = [ids.copy() for ids in tokens["input_ids"]]
        return tokens
    dataset = dataset.map(tokenize, batched=True, remove_columns=["text"])

    output = Path(args.output_dir)
    training_args = TrainingArguments(
        output_dir=str(output),
        num_train_epochs=args.epochs,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        save_strategy="epoch",
        logging_steps=5,
        report_to="none",
    )
    trainer = Trainer(model=model, args=training_args, train_dataset=dataset)
    trainer.train()
    model.save_pretrained(output)
    tokenizer.save_pretrained(output)
    print(f"Saved LoRA adapter to {output}. Evaluate it before relying on it.")

if __name__ == "__main__":
    main()
