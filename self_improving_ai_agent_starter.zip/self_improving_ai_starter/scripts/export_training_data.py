"""Export only explicitly approved feedback records to training JSONL."""
import json
from pathlib import Path
from agent import config

source = Path(config.DATA_DIR) / "reviewed_feedback.jsonl"
destination = Path(config.DATA_DIR) / "training.jsonl"
destination.parent.mkdir(parents=True, exist_ok=True)

count = 0
if not source.exists():
    print(f"No reviewed feedback found at {source}. Rate examples and review the file first.")
    raise SystemExit(0)

with source.open(encoding="utf-8") as inp, destination.open("w", encoding="utf-8") as out:
    for line in inp:
        try:
            row = json.loads(line)
        except json.JSONDecodeError:
            continue
        if row.get("rating") != "good":
            continue
        prompt, response = row.get("prompt"), row.get("response")
        if not isinstance(prompt, str) or not prompt.strip():
            continue
        if not isinstance(response, str) or not response.strip():
            continue
        out.write(json.dumps({"text": f"User: {prompt.strip()}\nAssistant: {response.strip()}"}, ensure_ascii=False) + "\n")
        count += 1

print(f"Exported {count} approved examples to {destination}. Inspect the file before training.")
