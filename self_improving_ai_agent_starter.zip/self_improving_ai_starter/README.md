# Self-Improving AI Agent (Starter)

A safe, beginner-friendly starter project for an AI agent that can run locally or in the cloud, record feedback, retrieve approved memories, and prepare a small fine-tuning dataset.

> **What “self-improving” means here:** the agent improves through explicit feedback and reviewed examples. It does **not** silently rewrite its own code, change permissions, or train itself on every conversation. Model training is a separate, deliberate step.

## Features

- Python agent with a local Ollama option and an optional OpenAI-compatible API provider.
- Simple persistent memory stored as JSON Lines.
- Explicit feedback capture for later review.
- Export reviewed examples to JSONL for supervised fine-tuning.
- Optional starter fine-tuning script using Hugging Face Transformers.
- Optional upload script for a model you own to your Hugging Face account.
- Unit tests and GitHub Actions workflow.

## 1. Requirements

- Python 3.10 or newer.
- For local inference: [Ollama](https://ollama.com/) and a model pulled in Ollama, such as `llama3.2:3b` (hardware-dependent).
- For cloud inference: an API key from a provider that supports the OpenAI chat-completions API.
- For fine-tuning: a compatible GPU is recommended. CPU training may be very slow.

## 2. Install

### Windows (PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

### Linux / macOS

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` only if you need cloud inference. Never commit `.env` or API keys.

## 3. Run locally

### Option A: Ollama (local model)

Install Ollama, then pull a model, for example:

```bash
ollama pull llama3.2:3b
```

Set in `.env`:

```env
AI_PROVIDER=ollama
OLLAMA_MODEL=llama3.2:3b
OLLAMA_BASE_URL=http://localhost:11434
```

Run:

```bash
python -m agent.cli
```

### Option B: OpenAI-compatible cloud API

Set in `.env`:

```env
AI_PROVIDER=openai_compatible
AI_API_KEY=replace_me
AI_BASE_URL=https://api.openai.com/v1
AI_MODEL=gpt-4o-mini
```

Use the model name supported by your chosen provider. API usage may incur charges.

## 4. Feedback and reviewed memory

Chat with the agent. After an answer, type `/good` or `/bad` to rate it, or `/quit` to exit. Feedback is stored in `data/feedback.jsonl`. The agent also stores short conversation records in `data/memory.jsonl`.

Review the data before using it for training. Do not include passwords, API keys, personal data, or private conversations without appropriate consent.

## 5. Build a fine-tuning dataset

After reviewing your feedback records:

```bash
python scripts/export_training_data.py
```

This writes `data/training.jsonl`. Inspect it before training. The exporter includes only entries marked `good` and skips records without both prompt and response.

## 6. Fine-tune a model (optional)

Install training dependencies:

```bash
pip install -r requirements-train.txt
```

Then:

```bash
python scripts/train_lora.py --base-model distilgpt2 --output-dir artifacts/self-improving-agent-lora
```

This is a **demonstration pipeline**, not a claim that the resulting small model is broadly intelligent. Use a properly licensed base model, clean examples, evaluation data, and suitable hardware. Do not train on raw unreviewed logs. For chat/instruction models, adapt the formatting and trainer to the model's official chat template.

## 7. Publish to Hugging Face

1. Create an account at https://huggingface.co/
2. Create a **model repository** (or Space if you want a hosted demo).
3. Install the optional upload dependency: `pip install -r requirements-hf.txt`
4. Log in: `hf auth login`
5. Upload an output folder you own:

```bash
python scripts/upload_to_huggingface.py --folder artifacts/self-improving-agent-lora --repo-id YOUR_USERNAME/self-improving-agent-lora
```

The upload script asks for an explicit confirmation before uploading. Keep private data and secrets out of the model folder.

## 8. Publish to GitHub

1. Create a new **public** repository at https://github.com/new (suggested name: `self-improving-ai-agent`).
2. Do not initialize it with a README if you plan to push this folder as-is.
3. Extract this ZIP, open a terminal in the extracted folder, then run:

```bash
git init
git add .
git commit -m "Initial self-improving AI agent starter"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/self-improving-ai-agent.git
git push -u origin main
```

Git may prompt you to authenticate through a browser. Never put a personal access token directly in a command or source file.

## 9. Run tests

```bash
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

## Safety and limitations

- Feedback is a candidate signal, not proof of correctness.
- The agent does not execute arbitrary shell commands or edit its own source.
- Memory and feedback files are stored locally by default.
- Cloud API prompts are sent to the selected provider.
- Model output may be wrong. Evaluate on held-out examples before using a fine-tuned model.
- This starter does not include a production authentication layer, multi-user database, or production deployment configuration.
