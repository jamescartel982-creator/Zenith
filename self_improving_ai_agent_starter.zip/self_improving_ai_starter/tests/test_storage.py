import os
import tempfile
import unittest
from unittest.mock import patch

class StorageTests(unittest.TestCase):
    def test_append_and_read_jsonl(self):
        with tempfile.TemporaryDirectory() as tmp:
            with patch.dict(os.environ, {"AGENT_DATA_DIR": tmp}):
                from agent import config
                from agent.storage import append_jsonl, read_jsonl
                config.DATA_DIR = tmp
                append_jsonl("test.jsonl", {"role": "user", "content": "hello"})
                rows = read_jsonl("test.jsonl")
                self.assertEqual(len(rows), 1)
                self.assertEqual(rows[0]["content"], "hello")
                self.assertIn("timestamp", rows[0])

if __name__ == "__main__":
    unittest.main()
