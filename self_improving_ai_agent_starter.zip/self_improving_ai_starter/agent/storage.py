"""Append-only JSONL storage for local memory and feedback."""
import json
from pathlib import Path
from datetime import datetime, timezone
from . import config

def _path(name: str) -> Path:
    path = Path(config.DATA_DIR) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    return path

def append_jsonl(name: str, record: dict) -> None:
    record = {**record, "timestamp": datetime.now(timezone.utc).isoformat()}
    with _path(name).open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")

def read_jsonl(name: str, limit: int = 100) -> list[dict]:
    path = _path(name)
    if not path.exists():
        return []
    records = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            try:
                records.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return records[-limit:]
