"""Small inference adapters: Ollama or an OpenAI-compatible chat API."""
import requests
from . import config

SYSTEM_PROMPT = (
    "You are a helpful AI agent. Be honest about uncertainty. "
    "Do not claim you have performed actions you have not performed. "
    "Do not request secrets. You cannot execute tools or modify your own code."
)

def generate(prompt: str) -> str:
    if config.AI_PROVIDER == "ollama":
        response = requests.post(
            f"{config.OLLAMA_BASE_URL}/api/chat",
            json={
                "model": config.OLLAMA_MODEL,
                "stream": False,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
            },
            timeout=180,
        )
        response.raise_for_status()
        return response.json()["message"]["content"].strip()

    if config.AI_PROVIDER == "openai_compatible":
        if not config.AI_API_KEY:
            raise RuntimeError("AI_API_KEY is empty. Add it to your local .env file.")
        response = requests.post(
            f"{config.AI_BASE_URL}/chat/completions",
            headers={"Authorization": f"Bearer {config.AI_API_KEY}"},
            json={
                "model": config.AI_MODEL,
                "messages": [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                "temperature": 0.4,
            },
            timeout=180,
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()

    raise RuntimeError("AI_PROVIDER must be 'ollama' or 'openai_compatible'.")
