"""Interactive command-line interface."""
from .core import answer, rate_last

def main():
    print("Self-Improving AI Agent starter. Type /quit to exit.")
    print("After an answer, use /good or /bad to record feedback.")
    print("Feedback is only a review signal; it does not automatically retrain the model.")
    while True:
        try:
            text = input("\nYou> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye.")
            break
        if not text:
            continue
        if text == "/quit":
            print("Goodbye.")
            break
        if text in {"/good", "/bad"}:
            ok = rate_last("good" if text == "/good" else "bad")
            print("Feedback saved for review." if ok else "No response to rate yet.")
            continue
        try:
            print("\nAgent> " + answer(text))
        except Exception as exc:
            print(f"\nError: {exc}")
            print("Check provider settings, network connection, and whether the local model is running.")

if __name__ == "__main__":
    main()
